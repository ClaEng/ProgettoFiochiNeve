Grazie per avermi scaricato.
Per il corretto funzionamento del software il file SnowFlakeGenerator.jar e la cartella lib devono essere nella stessa directory!!!